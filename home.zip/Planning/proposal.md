# Proposal

Complete the following...

## Group members (3-4, include name and email)

Kishan Patel: kishan_patel@uri.edu
Andrew Teh: andrew_teh@uri.edu
Kamden Ashmore: kashmore@uri.uri
Garrett Kemper: garrett_kemper@uri.edu

## Real-world Problem
counsilers not able to give adequate time to each student and give them good Recommendations

University CS Course Scheduler / Recommendation 
For guidance counsilers to imput all thier students info and get returned a genralized class list that they can build off of
and be able to handle the large amoutn of students they are given charge of.


## Data Structures & Algorithms (at least 3)

Range Tree
Flash Sort
Bloom Filter



